public class disciplinas {
    
        //Editor/programador: Luan Zelinski Corrêa - Turma: 3-54
        //
        //Dupla: Nicollas Ferrari Candinho
        //
        //OBS: O senhor me disse que eu estaria isento da 3, ou seja, eu faria
        //apenas a 1 e a 2 se o Nicollas estivesse a visualizar o que eu 
        //estivesse fazendo.

    String nome_disciplina;
}
